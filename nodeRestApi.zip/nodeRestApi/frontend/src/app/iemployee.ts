export interface IEmployee {
    "id":number,
    "name": string;
    "address": any;
    "email": string;
    "phone": number
}