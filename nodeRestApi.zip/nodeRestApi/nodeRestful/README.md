node init
npm install hapi --save

Create a Node Hapi Server
server.js

npm start


MySQL Database
Install MySQL package for Node using node package manager(NPM). 
npm install mysql --save

 npm install joi --save
 
 
 Encryption
We need to encrypt user password, bcrypt package will provide you the salt encryption code. 
$ npm install bcrypt --save